
"use strict";

let SetCompliancePunch = require('./SetCompliancePunch.js')
let StopController = require('./StopController.js')
let StartController = require('./StartController.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let RestartController = require('./RestartController.js')
let TorqueEnable = require('./TorqueEnable.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let SetSpeed = require('./SetSpeed.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')

module.exports = {
  SetCompliancePunch: SetCompliancePunch,
  StopController: StopController,
  StartController: StartController,
  SetComplianceSlope: SetComplianceSlope,
  RestartController: RestartController,
  TorqueEnable: TorqueEnable,
  SetComplianceMargin: SetComplianceMargin,
  SetSpeed: SetSpeed,
  SetTorqueLimit: SetTorqueLimit,
};
