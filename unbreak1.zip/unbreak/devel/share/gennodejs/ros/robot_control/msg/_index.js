
"use strict";

let fsrInput = require('./fsrInput.js');
let coord = require('./coord.js');
let accelerometr = require('./accelerometr.js');
let state = require('./state.js');
let contact = require('./contact.js');
let newtactile = require('./newtactile.js');
let rigid = require('./rigid.js');
let tactile = require('./tactile.js');

module.exports = {
  fsrInput: fsrInput,
  coord: coord,
  accelerometr: accelerometr,
  state: state,
  contact: contact,
  newtactile: newtactile,
  rigid: rigid,
  tactile: tactile,
};
